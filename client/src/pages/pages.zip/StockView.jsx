import { useEffect, useState } from "react";
import { Boxes, AlertTriangle } from "lucide-react";
import API from "../utils/api";
import toast from "react-hot-toast";

const StockView = () => {
  const [warehouses, setWarehouses] = useState([]);
  const [selectedWarehouse, setSelectedWarehouse] = useState("");
  const [stock, setStock] = useState([]);
  const [loadingWarehouses, setLoadingWarehouses] = useState(true);
  const [loadingStock, setLoadingStock] = useState(false);

  useEffect(() => {
    const fetchWarehouses = async () => {
      try {
        const res = await API.get("/warehouses");
        const list = res.data || [];
        setWarehouses(list);
        if (list.length > 0) setSelectedWarehouse(list[0]._id);
      } catch (err) {
        toast.error("Couldn't load warehouses");
      } finally {
        setLoadingWarehouses(false);
      }
    };
    fetchWarehouses();
  }, []);

  useEffect(() => {
    if (!selectedWarehouse) return;

    const fetchStock = async () => {
      setLoadingStock(true);
      try {
        const res = await API.get(`/stock/warehouse/${selectedWarehouse}`);
        setStock(res.data || []);
      } catch (err) {
        toast.error("Couldn't load stock");
      } finally {
        setLoadingStock(false);
      }
    };
    fetchStock();
  }, [selectedWarehouse]);

  if (loadingWarehouses) return <div style={styles.loadingText}>Loading warehouses...</div>;

  return (
    <div>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Stock</h1>
          <p style={styles.subtitle}>Current quantities by warehouse</p>
        </div>
        <select
          style={styles.select}
          value={selectedWarehouse}
          onChange={(e) => setSelectedWarehouse(e.target.value)}
        >
          {warehouses.map((w) => (
            <option key={w._id} value={w._id}>
              {w.name}
            </option>
          ))}
        </select>
      </div>

      <div style={styles.section}>
        {loadingStock ? (
          <p style={styles.emptyText}>Loading stock...</p>
        ) : stock.length === 0 ? (
          <p style={styles.emptyText}>No stock recorded at this warehouse yet.</p>
        ) : (
          <div style={styles.table}>
            <div style={styles.tableHeaderRow}>
              <span>Product</span>
              <span>SKU</span>
              <span>Category</span>
              <span>Quantity</span>
              <span>Status</span>
            </div>
            {stock.map((entry) => {
              const isLow = entry.currentQuantity <= entry.lowStockThreshold;
              return (
                <div key={entry._id} style={styles.tableRow}>
                  <span style={styles.tableCellBold}>
                    <Boxes size={14} style={{ marginRight: "6px", verticalAlign: "-2px" }} />
                    {entry.product?.name || "—"}
                  </span>
                  <span style={styles.tableCellMono}>{entry.product?.sku || "—"}</span>
                  <span style={styles.tableCell}>{entry.product?.category || "—"}</span>
                  <span style={styles.tableCell}>{entry.currentQuantity}</span>
                  <span>
                    {isLow ? (
                      <span style={styles.badgeLow}>
                        <AlertTriangle size={12} style={{ marginRight: "4px", verticalAlign: "-1px" }} />
                        Low Stock
                      </span>
                    ) : (
                      <span style={styles.badgeOk}>In Stock</span>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "20px",
  },
  title: { fontSize: "22px", fontWeight: 700, color: "#111827", margin: 0 },
  subtitle: { fontSize: "14px", color: "#64748b", marginTop: "4px" },
  select: {
    padding: "9px 14px",
    borderRadius: "8px",
    border: "1px solid #e2e8f0",
    fontSize: "14px",
    background: "#fff",
    minWidth: "200px",
  },
  section: {
    background: "#fff",
    borderRadius: "12px",
    padding: "8px 20px",
    border: "1px solid #e5e7eb",
  },
  emptyText: { fontSize: "13px", color: "#94a3b8", padding: "20px 0" },
  table: { display: "flex", flexDirection: "column" },
  tableHeaderRow: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr",
    padding: "12px 0",
    fontSize: "11px",
    fontWeight: 700,
    color: "#94a3b8",
    textTransform: "uppercase",
    letterSpacing: "0.03em",
    borderBottom: "1px solid #f1f5f9",
  },
  tableRow: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr",
    alignItems: "center",
    padding: "12px 0",
    borderBottom: "1px solid #f1f5f9",
    fontSize: "13px",
  },
  tableCellBold: { fontWeight: 600, color: "#111827" },
  tableCellMono: { color: "#64748b", fontFamily: "monospace", fontSize: "12px" },
  tableCell: { color: "#64748b" },
  badgeOk: {
    fontSize: "11px",
    fontWeight: 600,
    padding: "3px 10px",
    borderRadius: "999px",
    background: "#dcfce7",
    color: "#16a34a",
  },
  badgeLow: {
    fontSize: "11px",
    fontWeight: 600,
    padding: "3px 10px",
    borderRadius: "999px",
    background: "#fee2e2",
    color: "#dc2626",
    display: "inline-flex",
    alignItems: "center",
  },
  loadingText: { padding: "40px", color: "#94a3b8", fontSize: "14px" },
};

export default StockView;