import { useEffect, useState } from "react";
import { Package, Warehouse, Boxes, ArrowLeftRight } from "lucide-react";
import API from "../utils/api";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";

const TYPE_STYLES = {
  inbound: { label: "Inbound", bg: "#dcfce7", color: "#16a34a" },
  outbound: { label: "Outbound", bg: "#fee2e2", color: "#dc2626" },
  transfer_in: { label: "Transfer In", bg: "#dbeafe", color: "#2563eb" },
  transfer_out: { label: "Transfer Out", bg: "#ffedd5", color: "#ea580c" },
  adjustment: { label: "Adjustment", bg: "#f1f5f9", color: "#64748b" },
};

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    productCount: 0,
    warehouseCount: 0,
    totalStock: 0,
    movements: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [productsRes, warehousesRes, movementsRes] = await Promise.all([
          API.get("/products"),
          API.get("/warehouses"),
          API.get("/movements"),
        ]);

        const warehouses = warehousesRes.data || [];

        // No aggregate stock endpoint exists — sum currentQuantity per warehouse
        const stockPerWarehouse = await Promise.all(
          warehouses.map((w) => API.get(`/stock/warehouse/${w._id}`))
        );
        const totalStock = stockPerWarehouse.reduce(
          (sum, res) => sum + res.data.reduce((s, entry) => s + entry.currentQuantity, 0),
          0
        );

        setStats({
          productCount: productsRes.data?.length || 0,
          warehouseCount: warehouses.length,
          totalStock,
          movements: (movementsRes.data || []).slice(0, 5),
        });
      } catch (err) {
        toast.error("Couldn't load dashboard data");
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const cards = [
    { label: "Products", value: stats.productCount, icon: Package },
    { label: "Warehouses", value: stats.warehouseCount, icon: Warehouse },
    { label: "Total Stock", value: stats.totalStock, icon: Boxes },
    { label: "Recent Movements", value: stats.movements.length, icon: ArrowLeftRight },
  ];

  if (loading) {
    return <div style={styles.loadingText}>Loading dashboard...</div>;
  }

  return (
    <div>
      <div style={styles.header}>
        <h1 style={styles.title}>Welcome back{user?.name ? `, ${user.name}` : ""}</h1>
        <p style={styles.subtitle}>Here's what's happening across your warehouses.</p>
      </div>

      <div style={styles.cardGrid}>
        {cards.map(({ label, value, icon: Icon }) => (
          <div key={label} style={styles.card}>
            <div style={styles.cardIcon}>
              <Icon size={20} color="#fff" />
            </div>
            <div>
              <div style={styles.cardValue}>{value}</div>
              <div style={styles.cardLabel}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={styles.section}>
        <h2 style={styles.sectionTitle}>Recent Movements</h2>
        {stats.movements.length === 0 ? (
          <p style={styles.emptyText}>No movements recorded yet.</p>
        ) : (
          <div style={styles.table}>
            {stats.movements.map((m) => {
              const typeStyle = TYPE_STYLES[m.type] || TYPE_STYLES.adjustment;
              return (
                <div key={m._id} style={styles.tableRow}>
                  <span style={styles.tableCellBold}>{m.product?.name || "—"}</span>
                  <span style={{ ...styles.badge, background: typeStyle.bg, color: typeStyle.color }}>
                    {typeStyle.label}
                  </span>
                  <span style={styles.tableCell}>{m.quantity}</span>
                  <span style={styles.tableCell}>{m.warehouse?.name || "—"}</span>
                  <span style={styles.tableCell}>
                    {m.createdAt ? new Date(m.createdAt).toLocaleDateString() : "—"}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  header: { marginBottom: "24px" },
  title: { fontSize: "22px", fontWeight: 700, color: "#111827", margin: 0 },
  subtitle: { fontSize: "14px", color: "#64748b", marginTop: "4px" },
  cardGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "16px",
    marginBottom: "32px",
  },
  card: {
    background: "#fff",
    borderRadius: "12px",
    padding: "18px",
    display: "flex",
    alignItems: "center",
    gap: "14px",
    border: "1px solid #e5e7eb",
  },
  cardIcon: {
    width: "42px",
    height: "42px",
    borderRadius: "10px",
    background: "linear-gradient(135deg, #ef4444, #f59e0b)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  cardValue: { fontSize: "20px", fontWeight: 700, color: "#111827" },
  cardLabel: { fontSize: "12px", color: "#94a3b8" },
  section: {
    background: "#fff",
    borderRadius: "12px",
    padding: "20px",
    border: "1px solid #e5e7eb",
  },
  sectionTitle: { fontSize: "16px", fontWeight: 600, color: "#111827", marginTop: 0 },
  emptyText: { fontSize: "13px", color: "#94a3b8" },
  table: { display: "flex", flexDirection: "column", gap: "8px" },
  tableRow: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr",
    alignItems: "center",
    padding: "10px 0",
    borderBottom: "1px solid #f1f5f9",
    fontSize: "13px",
  },
  tableCellBold: { fontWeight: 600, color: "#111827" },
  tableCell: { color: "#64748b" },
  badge: {
    fontSize: "11px",
    fontWeight: 600,
    padding: "3px 10px",
    borderRadius: "999px",
    width: "fit-content",
  },
  loadingText: { padding: "40px", color: "#94a3b8", fontSize: "14px" },
};

export default Dashboard;