import { useEffect, useState } from "react";
import { Package, Plus, Pencil, Trash2, X, Search } from "lucide-react";
import API from "../utils/api";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";

const emptyForm = { name: "", sku: "", category: "", unitCost: "", description: "" };

const Products = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const fetchProducts = async (searchTerm = "") => {
    try {
      const res = await API.get("/products", { params: searchTerm ? { search: searchTerm } : {} });
      setProducts(res.data || []);
    } catch (err) {
      toast.error("Couldn't load products");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    const delay = setTimeout(() => fetchProducts(search), 400);
    return () => clearTimeout(delay);
  }, [search]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (p) => {
    setEditingId(p._id);
    setForm({
      name: p.name,
      sku: p.sku,
      category: p.category,
      unitCost: p.unitCost,
      description: p.description || "",
    });
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setForm(emptyForm);
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        sku: form.sku,
        category: form.category,
        unitCost: Number(form.unitCost),
        description: form.description,
      };

      if (editingId) {
        // sku is immutable after creation on the backend, so it's excluded from the update payload
        const { sku, ...updatePayload } = payload;
        await API.put(`/products/${editingId}`, updatePayload);
        toast.success("Product updated");
      } else {
        await API.post("/products", payload);
        toast.success("Product created");
      }

      closeForm();
      fetchProducts(search);
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this product? This cannot be undone.")) return;
    try {
      await API.delete(`/products/${id}`);
      toast.success("Product deleted");
      fetchProducts(search);
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    }
  };

  if (loading) return <div style={styles.loadingText}>Loading products...</div>;

  return (
    <div>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Products</h1>
          <p style={styles.subtitle}>{products.length} product{products.length !== 1 ? "s" : ""}</p>
        </div>
        {isAdmin && (
          <button style={styles.primaryBtn} onClick={openCreate}>
            <Plus size={16} />
            <span>Add Product</span>
          </button>
        )}
      </div>

      <div style={styles.searchWrapper}>
        <Search size={16} color="#94a3b8" />
        <input
          style={styles.searchInput}
          placeholder="Search by name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div style={styles.section}>
        {products.length === 0 ? (
          <p style={styles.emptyText}>No products found.</p>
        ) : (
          <div style={styles.table}>
            <div style={styles.tableHeaderRow}>
              <span>Product</span>
              <span>SKU</span>
              <span>Category</span>
              <span>Unit Cost</span>
              {isAdmin && <span></span>}
            </div>
            {products.map((p) => (
              <div key={p._id} style={styles.tableRow}>
                <span style={styles.tableCellBold}>
                  <Package size={14} style={{ marginRight: "6px", verticalAlign: "-2px" }} />
                  {p.name}
                </span>
                <span style={styles.tableCellMono}>{p.sku}</span>
                <span style={styles.tableCell}>{p.category}</span>
                <span style={styles.tableCell}>${Number(p.unitCost).toFixed(2)}</span>
                {isAdmin && (
                  <span style={styles.rowActions}>
                    <button style={styles.iconBtn} onClick={() => openEdit(p)} title="Edit">
                      <Pencil size={14} />
                    </button>
                    <button style={styles.iconBtn} onClick={() => handleDelete(p._id)} title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {showForm && (
        <div style={styles.overlay} onClick={closeForm}>
          <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
            <div style={styles.modalHeader}>
              <h2 style={styles.modalTitle}>{editingId ? "Edit Product" : "New Product"}</h2>
              <button style={styles.closeBtn} onClick={closeForm}>
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <label style={styles.label}>Name</label>
              <input
                style={styles.input}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />

              <label style={styles.label}>SKU</label>
              <input
                style={styles.input}
                value={form.sku}
                onChange={(e) => setForm({ ...form, sku: e.target.value })}
                required
                disabled={!!editingId}
              />

              <label style={styles.label}>Category</label>
              <input
                style={styles.input}
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                required
              />

              <label style={styles.label}>Unit Cost</label>
              <input
                style={styles.input}
                type="number"
                min="0"
                step="0.01"
                value={form.unitCost}
                onChange={(e) => setForm({ ...form, unitCost: e.target.value })}
                required
              />

              <label style={styles.label}>Description</label>
              <textarea
                style={{ ...styles.input, resize: "vertical", minHeight: "70px" }}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />

              <button style={styles.submitBtn} type="submit" disabled={saving}>
                {saving ? "Saving..." : editingId ? "Save Changes" : "Create Product"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: "20px",
  },
  title: { fontSize: "22px", fontWeight: 700, color: "#111827", margin: 0 },
  subtitle: { fontSize: "14px", color: "#64748b", marginTop: "4px" },
  primaryBtn: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    padding: "10px 16px",
    borderRadius: "8px",
    border: "none",
    background: "linear-gradient(135deg, #ef4444, #f59e0b)",
    color: "#fff",
    fontSize: "13px",
    fontWeight: 600,
    cursor: "pointer",
  },
  searchWrapper: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    background: "#fff",
    border: "1px solid #e2e8f0",
    borderRadius: "8px",
    padding: "9px 12px",
    marginBottom: "16px",
    maxWidth: "320px",
  },
  searchInput: {
    border: "none",
    outline: "none",
    fontSize: "14px",
    flex: 1,
  },
  section: {
    background: "#fff",
    borderRadius: "12px",
    padding: "8px 20px",
    border: "1px solid #e5e7eb",
  },
  emptyText: { fontSize: "13px", color: "#94a3b8", padding: "20px 0" },
  table: { display: "flex", flexDirection: "column" },
  tableHeaderRow: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr 1fr 1fr 0.6fr",
    padding: "12px 0",
    fontSize: "11px",
    fontWeight: 700,
    color: "#94a3b8",
    textTransform: "uppercase",
    letterSpacing: "0.03em",
    borderBottom: "1px solid #f1f5f9",
  },
  tableRow: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr 1fr 1fr 0.6fr",
    alignItems: "center",
    padding: "12px 0",
    borderBottom: "1px solid #f1f5f9",
    fontSize: "13px",
  },
  tableCellBold: { fontWeight: 600, color: "#111827" },
  tableCellMono: { color: "#64748b", fontFamily: "monospace", fontSize: "12px" },
  tableCell: { color: "#64748b" },
  rowActions: { display: "flex", gap: "6px" },
  iconBtn: {
    width: "26px",
    height: "26px",
    borderRadius: "6px",
    border: "1px solid #e5e7eb",
    background: "#fff",
    color: "#64748b",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
  },
  loadingText: { padding: "40px", color: "#94a3b8", fontSize: "14px" },
  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(15, 23, 42, 0.5)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 50,
  },
  modal: {
    background: "#fff",
    borderRadius: "14px",
    padding: "24px",
    width: "380px",
    maxWidth: "90vw",
  },
  modalHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "16px",
  },
  modalTitle: { fontSize: "16px", fontWeight: 700, color: "#111827", margin: 0 },
  closeBtn: { border: "none", background: "transparent", color: "#94a3b8", cursor: "pointer" },
  label: {
    display: "block",
    fontSize: "12px",
    fontWeight: 600,
    color: "#475569",
    marginBottom: "6px",
    marginTop: "12px",
  },
  input: {
    width: "100%",
    padding: "10px 12px",
    borderRadius: "8px",
    border: "1px solid #e2e8f0",
    fontSize: "14px",
    boxSizing: "border-box",
    fontFamily: "inherit",
  },
  submitBtn: {
    width: "100%",
    marginTop: "20px",
    padding: "11px",
    borderRadius: "8px",
    border: "none",
    background: "linear-gradient(135deg, #ef4444, #f59e0b)",
    color: "#fff",
    fontSize: "14px",
    fontWeight: 600,
    cursor: "pointer",
  },
};

export default Products;