const express = require("express");
const router = express.Router();
const {
  getStockByWarehouse,
  getStockByProduct,
  checkAvailability,
} = require("../controllers/stockController");
const { protect } = require("../middleware/authMiddleware");

router.get("/availability", protect, checkAvailability);
router.get("/warehouse/:warehouseId", protect, getStockByWarehouse);
router.get("/product/:productId", protect, getStockByProduct);

module.exports = router;