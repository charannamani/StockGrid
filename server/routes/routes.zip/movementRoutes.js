const express = require("express");
const router = express.Router();
const {
  createMovement,
  createTransfer,
  getMovementHistory,
} = require("../controllers/movementController");
const { protect } = require("../middleware/authMiddleware");

router.get("/", protect, getMovementHistory);
router.post("/", protect, createMovement);
router.post("/transfer", protect, createTransfer);

module.exports = router;