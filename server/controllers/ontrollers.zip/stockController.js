const Stock = require("../models/Stock");
const Product = require("../models/Product");

const getStockByWarehouse = async (req, res, next) => {
  try {
    const stock = await Stock.find({ warehouse: req.params.warehouseId })
      .populate("product", "name sku category unitCost");
    res.json(stock);
  } catch (error) {
    next(error);
  }
};

const getStockByProduct = async (req, res, next) => {
  try {
    const stock = await Stock.find({ product: req.params.productId })
      .populate("warehouse", "name address");

    const totalQuantity = stock.reduce((sum, entry) => sum + entry.currentQuantity, 0);

    res.json({ totalQuantity, byWarehouse: stock });
  } catch (error) {
    next(error);
  }
};

const checkAvailability = async (req, res, next) => {
  try {
    const { productId, quantity } = req.query;

    if (!productId || !quantity) {
      res.status(400);
      return next(new Error("productId and quantity are required"));
    }

    const requestedQty = Number(quantity);

    const product = await Product.findById(productId);
    if (!product) {
      res.status(404);
      return next(new Error("Product not found"));
    }

    const stockEntries = await Stock.find({ product: productId, currentQuantity: { $gt: 0 } })
      .populate("warehouse", "name address")
      .sort({ currentQuantity: -1 });

    const singleSource = stockEntries.find((entry) => entry.currentQuantity >= requestedQty);

    if (singleSource) {
      return res.json({
        fulfillable: true,
        strategy: "single_warehouse",
        options: [
          {
            warehouse: singleSource.warehouse,
            quantityAvailable: singleSource.currentQuantity,
          },
        ],
      });
    }

    const combination = [];
    let remaining = requestedQty;

    for (const entry of stockEntries) {
      if (remaining <= 0) break;
      const take = Math.min(entry.currentQuantity, remaining);
      combination.push({
        warehouse: entry.warehouse,
        quantityAvailable: entry.currentQuantity,
        quantityToUse: take,
      });
      remaining -= take;
    }

    if (remaining <= 0) {
      return res.json({
        fulfillable: true,
        strategy: "multi_warehouse",
        options: combination,
      });
    }

    const totalAvailable = stockEntries.reduce((sum, e) => sum + e.currentQuantity, 0);

    return res.json({
      fulfillable: false,
      strategy: "insufficient_stock",
      totalAvailable,
      shortfall: requestedQty - totalAvailable,
      options: combination,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getStockByWarehouse, getStockByProduct, checkAvailability };