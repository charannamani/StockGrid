const mongoose = require("mongoose");
const Stock = require("../models/Stock");
const StockMovement = require("../models/StockMovement");

const getOrCreateStock = async (product, warehouse, session) => {
  let stock = await Stock.findOne({ product, warehouse }).session(session);
  if (!stock) {
    const created = await Stock.create([{ product, warehouse, currentQuantity: 0 }], { session });
    stock = created[0];
  }
  return stock;
};

const createMovement = async (req, res, next) => {
  const session = await mongoose.startSession();
  try {
    session.startTransaction();

    const { product, warehouse, type, quantity, reason, direction } = req.body;

    if (!["inbound", "outbound", "adjustment"].includes(type)) {
      throw new Error("type must be inbound, outbound, or adjustment for this endpoint");
    }

    const qty = Number(quantity);
    const stock = await getOrCreateStock(product, warehouse, session);

    let delta = 0;
    if (type === "inbound") delta = qty;
    if (type === "outbound") delta = -qty;
    if (type === "adjustment") {
      if (!["increase", "decrease"].includes(direction)) {
        throw new Error("adjustment requires direction: increase or decrease");
      }
      delta = direction === "increase" ? qty : -qty;
    }

    const newQuantity = stock.currentQuantity + delta;
    if (newQuantity < 0) {
      throw new Error("Insufficient stock for this movement");
    }

    stock.currentQuantity = newQuantity;
    await stock.save({ session });

    const movement = await StockMovement.create(
      [
        {
          product,
          warehouse,
          type,
          quantity: qty,
          reason,
          performedBy: req.user._id,
        },
      ],
      { session }
    );

    await session.commitTransaction();
    res.status(201).json(movement[0]);
  } catch (error) {
    await session.abortTransaction();
    next(error);
  } finally {
    session.endSession();
  }
};

const createTransfer = async (req, res, next) => {
  const session = await mongoose.startSession();
  try {
    session.startTransaction();

    const { product, fromWarehouse, toWarehouse, quantity, reason } = req.body;
    const qty = Number(quantity);

    if (fromWarehouse === toWarehouse) {
      throw new Error("fromWarehouse and toWarehouse must be different");
    }

    const sourceStock = await getOrCreateStock(product, fromWarehouse, session);
    if (sourceStock.currentQuantity < qty) {
      throw new Error("Insufficient stock at source warehouse for this transfer");
    }

    const destStock = await getOrCreateStock(product, toWarehouse, session);

    sourceStock.currentQuantity -= qty;
    destStock.currentQuantity += qty;

    await sourceStock.save({ session });
    await destStock.save({ session });

    const outMovement = await StockMovement.create(
      [
        {
          product,
          warehouse: fromWarehouse,
          type: "transfer_out",
          quantity: qty,
          relatedWarehouse: toWarehouse,
          reason,
          performedBy: req.user._id,
        },
      ],
      { session }
    );

    const inMovement = await StockMovement.create(
      [
        {
          product,
          warehouse: toWarehouse,
          type: "transfer_in",
          quantity: qty,
          relatedWarehouse: fromWarehouse,
          reason,
          performedBy: req.user._id,
        },
      ],
      { session }
    );

    await session.commitTransaction();
    res.status(201).json({ transferOut: outMovement[0], transferIn: inMovement[0] });
  } catch (error) {
    await session.abortTransaction();
    next(error);
  } finally {
    session.endSession();
  }
};

const getMovementHistory = async (req, res, next) => {
  try {
    const { product, warehouse, startDate, endDate } = req.query;
    const filter = {};

    if (product) filter.product = product;
    if (warehouse) filter.warehouse = warehouse;
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const movements = await StockMovement.find(filter)
      .populate("product", "name sku")
      .populate("warehouse", "name")
      .populate("relatedWarehouse", "name")
      .populate("performedBy", "name email")
      .sort({ createdAt: -1 });

    res.json(movements);
  } catch (error) {
    next(error);
  }
};

module.exports = { createMovement, createTransfer, getMovementHistory };