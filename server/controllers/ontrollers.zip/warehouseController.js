const Warehouse = require("../models/Warehouse");

const getWarehouses = async (req, res, next) => {
  try {
    const warehouses = await Warehouse.find({ isActive: true });
    res.json(warehouses);
  } catch (error) {
    next(error);
  }
};

const getWarehouseById = async (req, res, next) => {
  try {
    const warehouse = await Warehouse.findById(req.params.id);
    if (!warehouse) {
      res.status(404);
      return next(new Error("Warehouse not found"));
    }
    res.json(warehouse);
  } catch (error) {
    next(error);
  }
};

const createWarehouse = async (req, res, next) => {
  try {
    const { name, address, capacity } = req.body;

    const exists = await Warehouse.findOne({ name });
    if (exists) {
      res.status(400);
      return next(new Error("A warehouse with this name already exists"));
    }

    const warehouse = await Warehouse.create({ name, address, capacity });
    res.status(201).json(warehouse);
  } catch (error) {
    next(error);
  }
};

const updateWarehouse = async (req, res, next) => {
  try {
    const warehouse = await Warehouse.findById(req.params.id);
    if (!warehouse) {
      res.status(404);
      return next(new Error("Warehouse not found"));
    }

    warehouse.name = req.body.name ?? warehouse.name;
    warehouse.address = req.body.address ?? warehouse.address;
    warehouse.capacity = req.body.capacity ?? warehouse.capacity;

    const updated = await warehouse.save();
    res.json(updated);
  } catch (error) {
    next(error);
  }
};

const deactivateWarehouse = async (req, res, next) => {
  try {
    const warehouse = await Warehouse.findById(req.params.id);
    if (!warehouse) {
      res.status(404);
      return next(new Error("Warehouse not found"));
    }

    warehouse.isActive = false;
    await warehouse.save();
    res.json({ message: "Warehouse deactivated" });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getWarehouses,
  getWarehouseById,
  createWarehouse,
  updateWarehouse,
  deactivateWarehouse,
};